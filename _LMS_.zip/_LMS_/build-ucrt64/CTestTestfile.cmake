# CMake generated Testfile for 
# Source directory: C:/Users/user/Documents/SCHOOL/4TH YEAR/FIRST_SEMESTER/CS4433 Software Engineering/Project/Prototype/CS4433_Week4_Implementation
# Build directory: C:/Users/user/Documents/SCHOOL/4TH YEAR/FIRST_SEMESTER/CS4433 Software Engineering/Project/Prototype/CS4433_Week4_Implementation/build-ucrt64
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(LMS_Business_Workflows "C:/Users/user/Documents/SCHOOL/4TH YEAR/FIRST_SEMESTER/CS4433 Software Engineering/Project/Prototype/CS4433_Week4_Implementation/build-ucrt64/lms_tests.exe")
set_tests_properties(LMS_Business_Workflows PROPERTIES  _BACKTRACE_TRIPLES "C:/Users/user/Documents/SCHOOL/4TH YEAR/FIRST_SEMESTER/CS4433 Software Engineering/Project/Prototype/CS4433_Week4_Implementation/CMakeLists.txt;24;add_test;C:/Users/user/Documents/SCHOOL/4TH YEAR/FIRST_SEMESTER/CS4433 Software Engineering/Project/Prototype/CS4433_Week4_Implementation/CMakeLists.txt;0;")
