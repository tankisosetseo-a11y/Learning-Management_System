@echo off
cd /d "%~dp0"
build-ucrt64\lms.exe
pause
